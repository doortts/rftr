


abstract public class Price {
	abstract int getPriceCode();

	abstract public double getCharge(int daysRented);
}
