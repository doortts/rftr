



public class ChildrensPrice extends Price {

  public ChildrensPrice() {
  }
  int getPriceCode() {
		return Movie.CHILDREN;
  }
}
