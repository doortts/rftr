


public class NewReleasePrice extends Price {

  public NewReleasePrice() {
  }
  int getPriceCode() {
    return Movie.NEW_RELEASE;
  }
}
