


abstract public class Price {
	abstract int getPriceCode();
}
