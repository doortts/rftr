



public class RegularPrice extends Price {

  public RegularPrice() {
  }
  int getPriceCode() {
   return Movie.REGULAR;
  }
}
