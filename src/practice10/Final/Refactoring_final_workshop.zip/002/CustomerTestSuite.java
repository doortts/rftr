

import junit.framework.*;


public class CustomerTestSuite {

  public CustomerTestSuite() {
  }

	public static void main(String[] args) {
	  TestSuite suite = new TestSuite();
		suite.addTest(new CustomerTest2("testStatement1"));
		suite.addTest(new CustomerTest2("testStatement2"));
		suite.addTest(new CustomerTest2("testStatement3"));
		junit.textui.TestRunner.run(suite);
	}
}
