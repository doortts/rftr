

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class CustomerTest {

  public CustomerTest() {
  }

	public void test() {
		testEmptyTape();
		System.err.println("--------------------------");
		test1Children1NewRelease();
		System.err.println("--------------------------");
		test2Children3NewReleases4Regular();
	}

	protected void testEmptyTape() {
	  Customer redcloth = new Customer("Red_Cloth");
		System.err.println(redcloth.statement());
	}

	protected void test1Children1NewRelease() {
	  Customer redcloth = new Customer("Red_Cloth");
		redcloth.addRental(new Rental(new Movie("����", Movie.CHILDREN), 1));
		redcloth.addRental(new Rental(new Movie("���ָ�", Movie.NEW_RELEASE), 6));
		System.err.println(redcloth.statement());
	}

	protected void test2Children3NewReleases4Regular() {
	  Customer redcloth = new Customer("Red_Cloth");

		redcloth.addRental(new Rental(new Movie("����", Movie.CHILDREN), 1));
		redcloth.addRental(new Rental(new Movie("�Ѹ�", Movie.CHILDREN), 9));

		redcloth.addRental(new Rental(new Movie("���ָ�", Movie.NEW_RELEASE), 2));
		redcloth.addRental(new Rental(new Movie("�Ŷ��� �޹�", Movie.NEW_RELEASE), 6));
		redcloth.addRental(new Rental(new Movie("���̶� 2", Movie.NEW_RELEASE), 6));

		redcloth.addRental(new Rental(new Movie("������ǻó1", Movie.REGULAR), 1));
		redcloth.addRental(new Rental(new Movie("������ǻó2", Movie.REGULAR), 3));
		redcloth.addRental(new Rental(new Movie("������ǻó3", Movie.REGULAR), 5));
		redcloth.addRental(new Rental(new Movie("�͹̳�����2", Movie.REGULAR), 7));

		System.err.println(redcloth.statement());
	}




  public static void main(String[] args) {
    CustomerTest customerTest = new CustomerTest();
		customerTest.test();
  }
}
