

import junit.framework.TestCase;

public class CustomerTest2 extends TestCase {
		private Rental rental1;
		private Rental rental2;
		private Rental rental3;
		private Rental rental4;
		private Rental rental5;
		private Rental rental6;
		private Rental rental7;
		private Rental rental8;
		private Rental rental9;

		protected void setUp() {
			rental1 = new Rental(new Movie("����", Movie.CHILDREN), 1);
			rental2 = new Rental(new Movie("�Ѹ�", Movie.CHILDREN), 9);

			rental3 = new Rental(new Movie("���ָ�", Movie.NEW_RELEASE), 2);
			rental4 = new Rental(new Movie("�Ŷ��� �޹�", Movie.NEW_RELEASE), 6);
			rental5 = new Rental(new Movie("���̶� 2", Movie.NEW_RELEASE), 6);

			rental6 = new Rental(new Movie("������ǻó1", Movie.REGULAR), 1);
			rental7 = new Rental(new Movie("������ǻó2", Movie.REGULAR), 3);
			rental8 = new Rental(new Movie("������ǻó3", Movie.REGULAR), 5);
			rental9 = new Rental(new Movie("�͹̳�����2", Movie.REGULAR), 7);
		}

		// no movie
		public void testStatement1() {
			Customer redcloth = new Customer("Red_Cloth");
			assertEquals(redcloth.statement(), "Rental Record for Red_Cloth\nAmount owed is 0.0\nYou earned 0 frequent renter points");
		}


		// 1Children1NewReleases
		public void testStatement2() {
			Customer redcloth = new Customer("Red_Cloth");
			redcloth.addRental(rental1);
			redcloth.addRental(rental3);
			assertEquals(redcloth.statement(), "Rental Record for Red_Cloth\n\t����	1.5\n\t���ָ�	6.0\nAmount owed is 7.5\nYou earned 3 frequent renter points");
		}


		// 2Children3NewReleases4Regular
		public void testStatement3() {
			Customer redcloth = new Customer("Red_Cloth");
			redcloth.addRental(rental1);
			redcloth.addRental(rental2);

			redcloth.addRental(rental3);
			redcloth.addRental(rental4);
			redcloth.addRental(rental5);

			redcloth.addRental(rental6);
			redcloth.addRental(rental7);
			redcloth.addRental(rental8);
			redcloth.addRental(rental9);

			assertEquals(redcloth.statement(), "Rental Record for Red_Cloth\n\t����	1.5\n\t�Ѹ�	10.5\n\t���ָ�	6.0\n\t�Ŷ��� �޹�	18.0\n\t���̶� 2	18.0\n\t������ǻó1	2.0\n\t������ǻó2	3.5\n\t������ǻó3	6.5\n\t�͹̳�����2	9.5\nAmount owed is 75.5\nYou earned 12 frequent renter points");
		}


		public CustomerTest2(String name) {
		  super(name);
		}
}
